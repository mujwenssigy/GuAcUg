package com.example.nbstv

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val webView: WebView = findViewById(R.id.webView)
        webView.loadUrl("https://gu.ac.ug/")
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
    }
}